As part of my ongoing fully anonymous secure-phone project, I have ported PolarSSL (mbed TLS) to both Windows 3.1 and Windows NT.
 
This FOSS crypto library is designed for embedded systems; the target, as described earlier, will be an 80C386EX-based Single Board Computer.

The current version of PolarSSL is 1.3.10.
 
System Requirements: 16-bit Windows
 �80386 or better processor
 �MS-DOS 3.3 or later (MS-DOS 5.0 recommended)
 �Windows 3.1/3.11
 �At least 4 MB of RAM
 
System Requirements: 32-bit DOS
 �80386 or better processor
 �MS-DOS 5.0 or later
 �At least 4 MB of RAM
 
System Requirements: 32-bit Windows
 �80386 or better processor
 �Windows NT 3.51, Windows 95 or later
 �At least 8 MB of RAM
 
Any computer running 64-bit Windows will be able to run the demonstration app without problems. 

Included in the download package:
 
polarssl_16.zip:
 �pssl16.dll � The main PolarSSL library (1.3.10)
 �pssl.exe � The demonstration app
 �pssha512.dll � The PolarSSL SHA-384/512 module (1.3.10): it had to be built separately, since most 
  compilers do NOT support 64-bit integer arithmetic on 16-bit platforms; the only one to do so is Sybase OpenWatcom.
 	�BUT, 64-bit integer arithmetic is a very complex operation in 16-bit mode; the operands, calculations, and final
	 result use ALL of the CPU registers (AX, BX, CX, DX) __at the same time__.
	�As a result, SHA-384 and SHA-512 operations will take time, even on modern 32-bit computers (and 64-bit computers
	 in legacy protected mode)
 �readme.txt � This file
 �licence.txt - The GNU Library General Public Licence, version 2
 
polarssl_16_32_64.zip:
 �polarssl.dll � The entire PolarSSL library (1.3.10)
 �polarssl.exe � The demo app, universal version for DOS, Windows NT 3.51+, Windows Vista 64+
 �/tnt_rtk � The Phar Lap TNT redistributable runtime for MS-DOS
 �readme.txt � This file
 �licence.txt - The GNU Library General Public Licence, version 2

INSTALLATION

32/64-bit Windows:
 �Just extract the root directory to a folder of your own choosing; you do NOT need to extract the Phar Lap TNT runtime.
 �You're all set!

MS-DOS (You will need PKZIP):
 �You need to extract the Phar Lap TNT runtime to C:\TNT. (do not keep folder names)
 �If done properly, the file TNT.EXE will be in C:\TNT.
 �You must now add the folder to your PATH statement: export (or SET) PATH=%PATH%;C:\TNT 
 (%PATH% is your existing PATH; do not enter it literally; that is not supported on MS-DOS anyway)
 �If done properly, you can extract POLARSSL.* to any folder, and run it; the native stub will attempt
  to look for TNT.EXE in your PATH. You should get a copyright notice, and a PolarSSL> prompt.

16-bit Windows 3.1 (You will need PKZIP or WinZip):
 �Extract the files to a folder of your own choosing.
 �You're all set!

VERSION HISTORY (DEMO APP)
 �v0.1beta - Initial release. Only supports string and file checksums. Includes online help system.

OTHER NOTES
 �The PolarSSL library is being made available under the terms of the GNU Library General Public Licence, version 2.
 �As such, the source code can be downloaded from https://polarssl.org.
 �The source code of the demo app will not be made available. It is NOT open-source.

COPYRIGHT
 �PolarSSL, mbed TLS are �&�2006-2008 Advanced RISC Machines Ltd - all rights reserved.